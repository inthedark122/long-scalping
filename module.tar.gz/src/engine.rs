use std::collections::{BTreeMap, HashMap};

use lte_strategy_bridge::abi::{
    Direction, ModuleClosePosition, ModuleEvent, ModuleIndicatorValue, ModuleInput,
    ModuleOpenPosition, ModuleOrderSide, ModuleOutput, ModulePlaceOrder, OrderRole,
};
use lte_strategy_bridge::indicator_access::{
    IndicatorField, IndicatorFieldKey, IndicatorKey, TimeframeSec,
};
use crate::state::{State, TfMovState};

const TF: i64 = 60;
const TF_5M: i64 = 300;
const TF_15M: i64 = 900;
const TF_30M: i64 = 1800;
const MRC: &str = "mrc_200";
const SMC_IND: &str = "smc";
const CANDLE_IND: &str = "candle";

// Band names used to build grid levels — entry fills at a band block that band
const LONG_ENTRY_BANDS: &[&str] = &[
    "l-db", "l-db-do", "l-do", "l-do-ds", "l-ds", "l-ds-di", "l-di", "l-di-ml", "l-ml",
];
const LONG_TP_BANDS: &[&str] = &[
    "l-ml+", "l-ml-ui", "l-ui", "l-ui-us", "l-us", "l-us-uo", "l-uo", "l-uo-ub", "l-ub",
];
const SHORT_ENTRY_BANDS: &[&str] = &[
    "s-ub", "s-ub-uo", "s-uo", "s-uo-us", "s-us", "s-us-ui", "s-ui", "s-ui-ml", "s-ml",
];
const SHORT_TP_BANDS: &[&str] = &[
    "s-ml+", "s-ml-di", "s-di", "s-di-ds", "s-ds", "s-ds-do", "s-do", "s-do-db", "s-db",
];

// ── Public entry ────────────────────────────────────────────────────────────

pub fn run(input: &ModuleInput, state: &mut State) -> ModuleOutput {
    match &input.event {
        ModuleEvent::Init => handle_init(input, state),
        ModuleEvent::Indicators { timeframes } => handle_indicators(input, state, timeframes),
        ModuleEvent::SugInfo => { state.ticks += 1; handle_sug_info(input, state) }
        ModuleEvent::FinishPosition { direction, .. } => handle_finish(input, state, *direction),
        ModuleEvent::NewPosition { .. } => ModuleOutput {
            debug: format!("new_pos t={} ln={:.1} sn={:.1}",
                state.ticks,
                input.positions.long.as_ref().map(|p| p.notional).unwrap_or(0.0),
                input.positions.short.as_ref().map(|p| p.notional).unwrap_or(0.0),
            ),
            ..Default::default()
        },
        ModuleEvent::OrderUpdate {
            direction,
            role,
            status,
            mark,
            ..
        } => handle_order_update(state, *direction, role, status, mark),
        ModuleEvent::Action { name: _, values } => handle_action(state, values),
        _ => ModuleOutput::default(),
    }
}

// ── OrderUpdate: track filled levels by mark ───────────────────────────────

fn handle_action(state: &mut State, values: &HashMap<String, serde_json::Value>) -> ModuleOutput {
    state.cfg.apply(values);
    ModuleOutput {
        debug: format!(
            "cfg brk={} imb={} sl={} ratio={} ntps_thr={} sl%={} seed={} cap={} cd={} near={}",
            state.cfg.breakout_guard, state.cfg.imbalance_guard, state.cfg.margin_sl,
            state.cfg.imbalance_ratio, state.cfg.breakout_ntps, state.cfg.sl_margin_pct,
            state.cfg.seed, state.cfg.cap, state.cfg.cooldown_ticks, state.cfg.nearest,
        ),
        ..Default::default()
    }
}

fn handle_order_update(
    state: &mut State,
    direction: Direction,
    role: &OrderRole,
    status: &str,
    mark: &Option<String>,
) -> ModuleOutput {
    if status != "Filled" {
        return ModuleOutput {
            debug: format!("order {:?} {} {:?}", direction, status, mark),
            ..Default::default()
        };
    }

    if let Some(m) = mark {
        // Transition-close stages: advance counter when each phase fills.
        if m.starts_with("tc-cs") { state.mode_close_s = state.mode_close_s.saturating_add(1); }
        if m.starts_with("tc-cl") { state.mode_close_l = state.mode_close_l.saturating_add(1); }

        if let Some(band) = m.split_once(':').map(|(_, b)| b) {
            state.filled.insert(band.to_string());
            update_fill_idx(state, direction, role, band);
        }

        return ModuleOutput {
            debug: format!(
                "fill {} {:?} {:?} filled={} idx=({},{},{},{}) cl={}/{}",
                m, direction, role, state.filled.len(),
                state.long_entry_idx, state.long_tp_idx,
                state.short_entry_idx, state.short_tp_idx,
                state.mode_close_l, state.mode_close_s,
            ),
            ..Default::default()
        };
    }

    ModuleOutput::default()
}

fn update_fill_idx(state: &mut State, dir: Direction, role: &OrderRole, band: &str) {
    let (arr, idx) = match (dir, role) {
        (Direction::Long, OrderRole::Entry) => (LONG_ENTRY_BANDS, &mut state.long_entry_idx),
        (Direction::Long, OrderRole::TakeProfit) => (LONG_TP_BANDS, &mut state.long_tp_idx),
        (Direction::Short, OrderRole::Entry) => (SHORT_ENTRY_BANDS, &mut state.short_entry_idx),
        (Direction::Short, OrderRole::TakeProfit) => (SHORT_TP_BANDS, &mut state.short_tp_idx),
        _ => return,
    };
    if let Some(pos) = arr.iter().position(|b| *b == band) {
        let i = pos as i8;
        if *idx < 0 { *idx = i; } else { *idx = (*idx).max(i); }
    }
}

// ── Init: fires once at bot start, indicators = full 10-candle history ────

fn handle_init(input: &ModuleInput, state: &mut State) -> ModuleOutput {
    state.history.init(&input.indicators);

    if let Some(bands) = read_mrc(&input.indicators) {
        apply_mrc_bands(state, &bands);
    }
    state.smc_dir = read_smc_dir(&input.indicators);

    for tf_sec in [TF, TF_5M, TF_15M, TF_30M] {
        init_tf_from_ind(&input.indicators, state, tf_sec);
    }

    // Rebuild movement cascade from last 10 candles and initialise risk ratchet.
    init_movement(&input.indicators, state);
    advance_market_mode(state);

    state.risk_init_max  = input.max_amount;
    state.risk_peak_auto = input.auto_max_amount.max(input.max_amount);
    state.risk_drawdown  = 1.0;

    ModuleOutput {
        debug: format!(
            "init t={} rng={:.2} ang={:.4} smc={} mode={} mv_cas={} avg={:.2} | 1m:{} | 5m:{} | 15m:{} | 30m:{}",
            state.ticks, state.mrc_range, state.angle, state.smc_dir,
            state.mkt_mode, state.mv_cas_dir, state.mv_avg_size,
            tf_debug(&state.tf1), tf_debug(&state.tf5),
            tf_debug(&state.tf15), tf_debug(&state.tf30),
        ),
        ..Default::default()
    }
}

// ── Indicators: new candle close, indicators = only the latest candle ─────

fn handle_indicators(input: &ModuleInput, state: &mut State, timeframes: &[i64]) -> ModuleOutput {
    state.last_ind_tick = state.ticks;
    state.history.update(&input.indicators, timeframes);

    if timeframes.contains(&TF) {
        if let Some(bands) = read_mrc(&input.indicators) {
            apply_mrc_bands(state, &bands);
        }
        state.smc_dir_prev = state.smc_dir;
        state.smc_dir = read_smc_dir(&input.indicators);
        update_volume_spike(&input.indicators, state);

        // Update movement cascade and re-evaluate market mode on each 1m close.
        let c_high = read_float(&input.indicators, TF, 0, CANDLE_IND, "High").unwrap_or(0.0);
        let c_low  = read_float(&input.indicators, TF, 0, CANDLE_IND, "Low").unwrap_or(0.0);
        update_movement(state, state.vol_bsg, c_high, c_low);
        advance_market_mode(state);
    }

    for &tf_sec in timeframes {
        advance_tf_from_ind(&input.indicators, state, tf_sec);
    }

    // Market auto-open only — one-shot per candle. Limit orders live in handle_sug_info.
    let open_positions = if timeframes.contains(&TF) && state.has_mrc {
        compute_auto_open(input, state)
    } else {
        vec![]
    };

    ModuleOutput {
        open_positions,
        debug: format!(
            "ind t={} rng={:.2} ang={:.4} smc={} mode={} mv_cas={}/{:.0} avg={:.2} brk={} | 1m:{} | 5m:{}",
            state.ticks, state.mrc_range, state.angle, state.smc_dir,
            state.mkt_mode, state.mv_cas_dir,
            state.mv_cas_high - state.mv_cas_low, state.mv_avg_size, state.mv_break_n,
            tf_debug(&state.tf1), tf_debug(&state.tf5),
        ),
        ..Default::default()
    }
}

// ── SugInfo: closes + reentry + grid placement ─────────────────────────────

fn handle_sug_info(input: &ModuleInput, state: &mut State) -> ModuleOutput {
    let (ntps, trandm) = read_analysis(input);
    state.ntps = ntps;
    state.trandm = trandm;

    let price = input.price;
    let max = input.max_amount.max(input.auto_max_amount);
    let margin = if input.leverage > 0 { max / input.leverage as f64 } else { max / 100.0 };

    let long_n   = input.positions.long.as_ref().map(|p| p.notional).unwrap_or(0.0);
    let short_n  = input.positions.short.as_ref().map(|p| p.notional).unwrap_or(0.0);
    let long_pnl = input.positions.long.as_ref().map(|p| p.pnl).unwrap_or(0.0);
    let short_pnl = input.positions.short.as_ref().map(|p| p.pnl).unwrap_or(0.0);
    let has_long  = input.positions.long.is_some();
    let has_short = input.positions.short.is_some();
    let total_pnl = long_pnl + short_pnl;

    // Update risk ratchet before computing anything else.
    update_risk_ratchet(state, input.max_amount, input.auto_max_amount);

    let smc_dir = match state.smc_dir { 1 => Some(Direction::Long), -1 => Some(Direction::Short), _ => None };
    let mkt_mode = state.mkt_mode;

    let mut close_positions: Vec<ModuleClosePosition> = Vec::new();

    // ── SL: last-resort margin protection ──────────────────────────────
    if state.cfg.margin_sl && total_pnl < -(margin * state.cfg.sl_margin_pct) {
        if has_long  && long_n  > 1.0 { close_positions.push(close(Direction::Long,  "MARGIN SL")); }
        if has_short && short_n > 1.0 { close_positions.push(close(Direction::Short, "MARGIN SL")); }
    }

    // ── NTPS momentum close ─────────────────────────────────────────────
    if ntps > 600 {
        if smc_dir == Some(Direction::Long)  && has_short && short_n > 1.0 { close_positions.push(close(Direction::Short, "NTPS LONG")); }
        if smc_dir == Some(Direction::Short) && has_long  && long_n  > 1.0 { close_positions.push(close(Direction::Long,  "NTPS SHORT")); }
    }

    // Track minimum distance from price to each MRC band each tick
    update_level_min_dists(state, price);

    // ── Kickstart: force open after 120 ticks with no position ───────────────
    // Priority 1.5: same free-margin estimate as compute_auto_open.
    // long_n, short_n, margin, total_pnl are all already computed above from live position data.
    let committed_margin_ks = (long_n + short_n) / input.leverage.max(1) as f64;
    let free_margin_ks      = margin - committed_margin_ks + total_pnl;
    let balance_viable = margin <= 0.0 || free_margin_ks >= margin * 0.10;
    let mut open_positions: Vec<ModuleOpenPosition> = Vec::new();
    if state.has_mrc && !has_long && !has_short && balance_viable
        && state.ticks > 0 && state.ticks % 120 == 0
    {
        let pzone = (price - state.mrc_db) / (state.mrc_ub - state.mrc_db).max(f64::EPSILON);
        let dir_opt = if mkt_mode == 2 { Some(Direction::Long) }
                      else if mkt_mode == -2 { Some(Direction::Short) }
                      else if mkt_mode == 1 {
                          // Sideways: only kickstart where price is directionally sensible
                          if pzone < 0.4 { Some(Direction::Long) }
                          else if pzone > 0.6 { Some(Direction::Short) }
                          else { None }
                      }
                      else if state.interest_dir == 1 { Some(Direction::Long) }
                      else if state.interest_dir == -1 { Some(Direction::Short) }
                      else if state.tf5.regime == 2 { Some(Direction::Long) }
                      else { Some(Direction::Short) };
        if let Some(dir) = dir_opt {
            let amt = max * 0.15 * state.risk_drawdown;
            if amt > 1.0 { open_positions.push(market_open(dir, amt, "kickstart")); }
        }
    }

    let tick = input.symbol_info.price_tick_size.max(f64::EPSILON);
    let mut place_orders = if state.has_mrc { compute_limit_orders(input, state) } else { vec![] };

    // ── Trend mode: gradual transition close for the wrong-side position ────
    // Stage 0→1: 25% close after 2 candles of confirmed trend.
    // Stage 1→2: another 25% after 5 candles.
    // Stage 2→3: remaining 50% after 8 candles.
    let mc = state.mkt_mode_candles;
    if mkt_mode == 2 && has_short && short_n > 1.0 {
        let (stage, min_can, pct, mark): (u8, u32, f64, &str) = match state.mode_close_s {
            0 => (0, 2,  0.25, "tc-cs1"),
            1 => (1, 5,  0.25, "tc-cs2"),
            2 => (2, 8,  0.50, "tc-cs3"),
            _ => (3, u32::MAX, 0.0, ""),
        };
        if mc >= min_can && pct > 0.0 {
            let amt = short_n * pct;
            if amt > 1.0 {
                place_orders.push(tp_order_with_band(Direction::Short, amt, price + tick, mark, mark));
            }
        }
        let _ = stage; // suppress warning
    }
    if mkt_mode == -2 && has_long && long_n > 1.0 {
        let (stage, min_can, pct, mark): (u8, u32, f64, &str) = match state.mode_close_l {
            0 => (0, 2,  0.25, "tc-cl1"),
            1 => (1, 5,  0.25, "tc-cl2"),
            2 => (2, 8,  0.50, "tc-cl3"),
            _ => (3, u32::MAX, 0.0, ""),
        };
        if mc >= min_can && pct > 0.0 {
            let amt = long_n * pct;
            if amt > 1.0 {
                place_orders.push(tp_order_with_band(Direction::Long, amt, price - tick, mark, mark));
            }
        }
        let _ = stage;
    }

    // Priority 1.4: staged partial SL — at 50% of full SL threshold, reduce the losing side
    // by 30% via a reduce-only limit order near market price (fills on the very next tick).
    // Only fires when no full SL is already in progress (close_positions is empty).
    let early_sl_threshold = -(margin * state.cfg.sl_margin_pct * 0.50);
    if state.cfg.margin_sl && close_positions.is_empty() && total_pnl < early_sl_threshold {
        if has_long && long_pnl < 0.0 && long_pnl <= short_pnl && long_n > 1.0 {
            let amt = long_n * 0.30;
            if amt > 1.0 { place_orders.push(tp_order_with_band(Direction::Long, amt, price - tick, "psl-l", "psl-l")); }
        }
        if has_short && short_pnl < 0.0 && short_pnl < long_pnl && short_n > 1.0 {
            let amt = short_n * 0.30;
            if amt > 1.0 { place_orders.push(tp_order_with_band(Direction::Short, amt, price + tick, "psl-s", "psl-s")); }
        }
    }

    let ord_count = place_orders.len();
    let kst = !open_positions.is_empty();

    ModuleOutput {
        open_positions,
        close_positions,
        place_orders,
        debug: format!(
            "sug t={} p={:.2} ntps={} mode={} mv={}/{:.0}(a={:.0}) brk={} drf={:.2} | ln={:.1} sn={:.1} pnl={:.4} sl={:.2} ord={}{}",
            state.ticks, price, ntps,
            state.mkt_mode, state.mv_cas_dir,
            state.mv_cas_high - state.mv_cas_low, state.mv_avg_size,
            state.mv_break_n, state.risk_drawdown,
            long_n, short_n, total_pnl, -(margin * state.cfg.sl_margin_pct),
            ord_count,
            if kst { " KST" } else { "" },
        ),
        ..Default::default()
    }
}

// ── Auto-open: market entries, called once per 1m candle from handle_indicators ──

fn compute_auto_open(input: &ModuleInput, state: &State) -> Vec<ModuleOpenPosition> {
    let price = input.price;
    let max   = input.max_amount.max(input.auto_max_amount);
    // Priority 1.5: real-time free-margin estimate.
    // auto_max_amount only updates on position close — combine committed margin + live PnL instead.
    //   total_margin    = max budget / leverage
    //   committed_margin = open notional / leverage  (margin already locked by existing positions)
    //   free_margin_est  = total_margin − committed_margin + live_pnl
    // When free_margin_est drops near zero the balance is frozen and new opens will be rejected.
    let leverage = input.leverage.max(1) as f64;
    let total_margin = max / leverage;
    let live_pnl = input.positions.long.as_ref().map(|p| p.pnl).unwrap_or(0.0)
        + input.positions.short.as_ref().map(|p| p.pnl).unwrap_or(0.0);
    let open_notional = input.positions.long.as_ref().map(|p| p.notional).unwrap_or(0.0)
        + input.positions.short.as_ref().map(|p| p.notional).unwrap_or(0.0);
    let committed_margin = open_notional / leverage;
    let free_margin_est  = total_margin - committed_margin + live_pnl;
    if total_margin > 0.0 && free_margin_est < total_margin * 0.10 {
        return vec![];
    }
    let has_long  = input.positions.long.is_some();
    let has_short = input.positions.short.is_some();
    let mode    = state.tf5.regime;
    let cross1m = state.tf1.cross;
    let now1m   = state.tf1.candles;
    let smc_dir = match state.smc_dir { 1 => Some(Direction::Long), -1 => Some(Direction::Short), _ => None };
    let pzone   = (price - state.mrc_db) / (state.mrc_ub - state.mrc_db).max(f64::EPSILON);
    let (long_alloc, short_alloc) = compute_allocation(smc_dir, pzone, state.angle, state.tf5.mov, mode);
    let (lbias, sbias)            = compute_bias(state.angle, pzone, state.trandm, state.tf5.mov);
    let (lscale, sscale)          = compute_entry_scale(state, pzone);
    let breakout_long  = state.cfg.breakout_guard && smc_dir == Some(Direction::Long)  && state.ntps > state.cfg.breakout_ntps;
    let breakout_short = state.cfg.breakout_guard && smc_dir == Some(Direction::Short) && state.ntps > state.cfg.breakout_ntps;
    let long_on_cd  = state.long_close_tick  > 0 && state.ticks.saturating_sub(state.long_close_tick)  < state.cfg.cooldown_ticks;
    let short_on_cd = state.short_close_tick > 0 && state.ticks.saturating_sub(state.short_close_tick) < state.cfg.cooldown_ticks;
    // Priority 1.2: low-NTPS directional drift gate (same as compute_limit_orders)
    let recent_bull_exh = state.bsg_exhaustion_long_candle > 0
        && state.tf1.candles.saturating_sub(state.bsg_exhaustion_long_candle) <= 3;
    let recent_bear_exh = state.bsg_exhaustion_short_candle > 0
        && state.tf1.candles.saturating_sub(state.bsg_exhaustion_short_candle) <= 3;
    let short_drift_blocked = state.ntps > 0 && state.ntps < 150
        && state.vol_bsg > 0.5 && !recent_bull_exh;
    let long_drift_blocked  = state.ntps > 0 && state.ntps < 150
        && state.vol_bsg < -0.5 && !recent_bear_exh;

    let v_bull_fresh = [3usize, 2, 1, 0].iter().any(|&i| {
        let ls = &state.level_stats[i];
        ls.v_bull > 0 && ls.last_v_candle > 0 && now1m.saturating_sub(ls.last_v_candle) <= 5
    });
    let v_bear_fresh = [5usize, 6, 7, 8].iter().any(|&i| {
        let ls = &state.level_stats[i];
        ls.v_bear > 0 && ls.last_v_candle > 0 && now1m.saturating_sub(ls.last_v_candle) <= 5
    });

    let stair_long_bid: usize  = match cross1m { -3=>0,-2=>1,-1=>2, 0=>3, 1=>5, 2=>6, 3=>7, 4=>8, _=>9 };
    let stair_short_bid: usize = match cross1m { -4=>0,-3=>1,-2=>2,-1=>3, 0=>5, 1=>6, 2=>7, 3=>8, _=>9 };
    let cross_streak = if (-4..=4).contains(&cross1m) { state.zone_streak[(cross1m + 4) as usize] } else { 0 };
    let debounced = cross_streak >= 2 && cross_streak <= 12;
    let vol_exhausted = state.vol_gain_max > 0.5 && state.vol_gain < 0.0 && state.vol_gain < state.vol_gain_prev;

    let stair_long_ok = debounced && stair_long_bid < 9 && {
        let ls = &state.level_stats[stair_long_bid];
        ls.last_cross_dir == 1 && ls.last_cross_candle > 0
            && now1m.saturating_sub(ls.last_cross_candle) <= 12
            && !vol_exhausted
            && (state.vol_bsg >= -0.1 || state.vol_gain > state.vol_gain_max * 0.3)
    };
    let stair_short_ok = debounced && stair_short_bid < 9 && {
        let ls = &state.level_stats[stair_short_bid];
        ls.last_cross_dir == -1 && ls.last_cross_candle > 0
            && now1m.saturating_sub(ls.last_cross_candle) <= 12
            && !vol_exhausted
            && (state.vol_bsg <= 0.1 || state.vol_gain > state.vol_gain_max * 0.3)
    };

    let gain_range_st = (state.vol_gain_max - state.vol_gain_min).max(f64::EPSILON);
    let gain_pct_st   = (state.vol_gain - state.vol_gain_min) / gain_range_st;
    let bsg_range_st  = (state.vol_bsg_max - state.vol_bsg_min).max(f64::EPSILON);
    let bsg_pct_st    = (state.vol_bsg  - state.vol_bsg_min)  / bsg_range_st;

    let stair_lscale: f64 = if stair_long_bid < 9 {
        let v_mult = match state.level_stats[stair_long_bid].v_bear { 0=>0.80,1=>1.00,2=>1.20,3=>1.40,_=>1.50_f64 };
        let vol_mult = if gain_pct_st > 0.55 && bsg_pct_st > 0.55 { 1.30 } else if gain_pct_st > 0.35 { 1.10 } else { 0.85 };
        (v_mult * vol_mult).clamp(0.50, 2.00)
    } else { 1.0 };
    let stair_sscale: f64 = if stair_short_bid < 9 {
        let v_mult = match state.level_stats[stair_short_bid].v_bull { 0=>0.80,1=>1.00,2=>1.20,3=>1.40,_=>1.50_f64 };
        let vol_mult = if gain_pct_st > 0.55 && bsg_pct_st < 0.45 { 1.30 } else if gain_pct_st > 0.35 { 1.10 } else { 0.85 };
        (v_mult * vol_mult).clamp(0.50, 2.00)
    } else { 1.0 };

    let mut open_positions: Vec<ModuleOpenPosition> = Vec::new();

    if !has_long && !long_on_cd && !breakout_short && !long_drift_blocked {
        let remaining = max * long_alloc * state.cfg.cap;
        let (trigger, extra) = match mode {
            2  => (stair_long_ok,                                    stair_lscale),
            -2 => (price <= state.mrc_db,                            1.0),
            1  => (cross1m <= 0 && v_bull_fresh && pzone < 0.5,      1.0),
            _  => (false, 1.0),
        };
        if trigger {
            let amt = remaining * 0.35 * lbias * lscale * extra;
            if amt > 1.0 { open_positions.push(market_open(Direction::Long, amt, "auto-l")); }
        }
    }
    if !has_short && !short_on_cd && !breakout_long && !short_drift_blocked {
        let remaining = max * short_alloc * state.cfg.cap;
        let (trigger, extra) = match mode {
            -2 => (stair_short_ok,                                   stair_sscale),
            2  => (price >= state.mrc_ub,                            1.0),
            1  => (cross1m >= 0 && v_bear_fresh && pzone > 0.5,      1.0),
            _  => (false, 1.0),
        };
        if trigger {
            let amt = remaining * 0.35 * sbias * sscale * extra;
            if amt > 1.0 { open_positions.push(market_open(Direction::Short, amt, "auto-s")); }
        }
    }

    open_positions
}

// ── Limit orders: entries + TPs, returned every SugInfo tick (mark = create-or-update) ──

fn compute_limit_orders(input: &ModuleInput, state: &State) -> Vec<ModulePlaceOrder> {
    let price = input.price;
    let tick  = input.symbol_info.price_tick_size.max(f64::EPSILON);
    let max   = input.max_amount.max(input.auto_max_amount);
    let min_tp_notional = (max * state.cfg.seed).max(1.0);
    let long_n  = input.positions.long.as_ref().map(|p| p.notional).unwrap_or(0.0);
    let short_n = input.positions.short.as_ref().map(|p| p.notional).unwrap_or(0.0);
    let has_long  = input.positions.long.is_some();
    let has_short = input.positions.short.is_some();
    let mode     = state.tf5.regime;
    let mkt_mode = state.mkt_mode;  // 0=UNK 1=Sideways 2=TrendLong -2=TrendShort
    let drf      = state.risk_drawdown;  // entry size scale factor from risk ratchet
    let smc_dir  = match state.smc_dir { 1 => Some(Direction::Long), -1 => Some(Direction::Short), _ => None };
    let pzone   = (price - state.mrc_db) / (state.mrc_ub - state.mrc_db).max(f64::EPSILON);
    let (long_alloc, short_alloc) = compute_allocation(smc_dir, pzone, state.angle, state.tf5.mov, mode);
    let (lbias, sbias)            = compute_bias(state.angle, pzone, state.trandm, state.tf5.mov);
    let (lscale, sscale)          = compute_entry_scale(state, pzone);
    let lwm = win_mult(input.positions.long.as_ref());
    let swm = win_mult(input.positions.short.as_ref());
    let breakout_long  = state.cfg.breakout_guard && smc_dir == Some(Direction::Long)  && state.ntps > state.cfg.breakout_ntps;
    let breakout_short = state.cfg.breakout_guard && smc_dir == Some(Direction::Short) && state.ntps > state.cfg.breakout_ntps;
    let imbalance_ok_long  = !state.cfg.imbalance_guard || short_n == 0.0 || long_n  < short_n * state.cfg.imbalance_ratio;
    let imbalance_ok_short = !state.cfg.imbalance_guard || long_n  == 0.0 || short_n < long_n  * state.cfg.imbalance_ratio;
    let long_on_cd  = state.long_close_tick  > 0 && state.ticks.saturating_sub(state.long_close_tick)  < state.cfg.cooldown_ticks;
    let short_on_cd = state.short_close_tick > 0 && state.ticks.saturating_sub(state.short_close_tick) < state.cfg.cooldown_ticks;

    let long_max  = max * long_alloc;
    let short_max = max * short_alloc;

    let long_entry_levels: Vec<(f64, &str)> = vec![
        (state.mrc_db,                    LONG_ENTRY_BANDS[0]),
        (mid(state.mrc_db, state.mrc_do), LONG_ENTRY_BANDS[1]),
        (state.mrc_do,                    LONG_ENTRY_BANDS[2]),
        (mid(state.mrc_do, state.mrc_ds), LONG_ENTRY_BANDS[3]),
        (state.mrc_ds,                    LONG_ENTRY_BANDS[4]),
        (mid(state.mrc_ds, state.mrc_di), LONG_ENTRY_BANDS[5]),
        (state.mrc_di,                    LONG_ENTRY_BANDS[6]),
        (mid(state.mrc_di, state.mrc_ml), LONG_ENTRY_BANDS[7]),
        (state.mrc_ml,                    LONG_ENTRY_BANDS[8]),
    ];
    let long_tp_levels: Vec<(f64, &str)> = vec![
        (state.mrc_ml,                    LONG_TP_BANDS[0]),
        (mid(state.mrc_ml, state.mrc_ui), LONG_TP_BANDS[1]),
        (state.mrc_ui,                    LONG_TP_BANDS[2]),
        (mid(state.mrc_ui, state.mrc_us), LONG_TP_BANDS[3]),
        (state.mrc_us,                    LONG_TP_BANDS[4]),
        (mid(state.mrc_us, state.mrc_uo), LONG_TP_BANDS[5]),
        (state.mrc_uo,                    LONG_TP_BANDS[6]),
        (mid(state.mrc_uo, state.mrc_ub), LONG_TP_BANDS[7]),
        (state.mrc_ub,                    LONG_TP_BANDS[8]),
    ];
    let short_entry_levels: Vec<(f64, &str)> = vec![
        (state.mrc_ub,                    SHORT_ENTRY_BANDS[0]),
        (mid(state.mrc_ub, state.mrc_uo), SHORT_ENTRY_BANDS[1]),
        (state.mrc_uo,                    SHORT_ENTRY_BANDS[2]),
        (mid(state.mrc_uo, state.mrc_us), SHORT_ENTRY_BANDS[3]),
        (state.mrc_us,                    SHORT_ENTRY_BANDS[4]),
        (mid(state.mrc_us, state.mrc_ui), SHORT_ENTRY_BANDS[5]),
        (state.mrc_ui,                    SHORT_ENTRY_BANDS[6]),
        (mid(state.mrc_ui, state.mrc_ml), SHORT_ENTRY_BANDS[7]),
        (state.mrc_ml,                    SHORT_ENTRY_BANDS[8]),
    ];
    let short_tp_levels: Vec<(f64, &str)> = vec![
        (state.mrc_ml,                    SHORT_TP_BANDS[0]),
        (mid(state.mrc_ml, state.mrc_di), SHORT_TP_BANDS[1]),
        (state.mrc_di,                    SHORT_TP_BANDS[2]),
        (mid(state.mrc_di, state.mrc_ds), SHORT_TP_BANDS[3]),
        (state.mrc_ds,                    SHORT_TP_BANDS[4]),
        (mid(state.mrc_ds, state.mrc_do), SHORT_TP_BANDS[5]),
        (state.mrc_do,                    SHORT_TP_BANDS[6]),
        (mid(state.mrc_do, state.mrc_db), SHORT_TP_BANDS[7]),
        (state.mrc_db,                    SHORT_TP_BANDS[8]),
    ];

    let mut place_orders: Vec<ModulePlaceOrder> = Vec::new();

    // Block entries on the wrong side when in a confirmed trend.
    // Also keep the vol_bsg gate when tf5 is trending (finer-grained signal).
    // Hard NTPS > 400 gate: when the market is very active and BSG confirms direction,
    // suppress counter-pressure entries to avoid adding into a fast-moving adverse move.
    let ntps_high = state.ntps > 400;
    // Priority 1.1: BSG exhaustion gate — counter-trend entry only allowed if a buy/sell
    // climax candle (BSG > 2.0) fired within the last 3 candles (potential reversal window).
    let recent_bull_exh = state.bsg_exhaustion_long_candle > 0
        && state.tf1.candles.saturating_sub(state.bsg_exhaustion_long_candle) <= 3;
    let recent_bear_exh = state.bsg_exhaustion_short_candle > 0
        && state.tf1.candles.saturating_sub(state.bsg_exhaustion_short_candle) <= 3;
    // Priority 1.2: low-NTPS directional drift — sustained user-interest move with no exhaustion.
    // ntps > 0 guard: skip during warmup ticks before first SugInfo sets ntps.
    let short_drift_blocked = state.ntps > 0 && state.ntps < 150
        && state.vol_bsg > 0.5 && !recent_bull_exh;
    let long_drift_blocked  = state.ntps > 0 && state.ntps < 150
        && state.vol_bsg < -0.5 && !recent_bear_exh;
    let long_entry_ok  = mkt_mode != -2
        && (mode != -2 || state.vol_bsg >= 0.0)
        && !(ntps_high && state.vol_bsg < 0.0)
        && !long_drift_blocked;
    let short_entry_ok = mkt_mode != 2
        && (mode != 2  || state.vol_bsg <= 0.0)
        && !(ntps_high && state.vol_bsg > 0.0)
        && !short_drift_blocked;

    // ── Long entries ─────────────────────────────────────────────────────────
    if has_long && long_entry_ok && !long_on_cd && !breakout_short && imbalance_ok_long && long_n < long_max * state.cfg.cap {
        let remaining = long_max * state.cfg.cap - long_n;
        let mut candidates: Vec<(f64, &str)> = long_entry_levels.iter()
            .filter(|(p, band)| *p > 0.0 && *p < price && !state.filled.contains(*band))
            .copied().collect();
        candidates.sort_by(|a, b| (price - a.0).partial_cmp(&(price - b.0)).unwrap_or(std::cmp::Ordering::Equal));
        let marks = ["l-e1", "l-e2"];
        let weights = [0.35, 0.25];
        for (i, &(bp, band)) in candidates.iter().take(state.cfg.nearest).enumerate() {
            let amt = (remaining * weights[i] * lbias * lwm * lscale * drf).min(remaining);
            if amt > 1.0 { place_orders.push(limit_order_with_band(Direction::Long, amt, bp, marks[i], band)); }
        }
        if candidates.is_empty() && price < state.mrc_db && remaining > 1.0 && state.vol_bsg > 0.0 {
            let ext_price = price - (state.mrc_range * 0.10).max(4.0 * tick);
            let amt = (remaining * 0.15 * lbias * lwm * lscale * drf).min(remaining);
            if amt > 1.0 { place_orders.push(limit_order(Direction::Long, amt, ext_price, "l-ext")); }
        }
    }

    // ── Cascade DCA entries: long (TrendLong mode only) ───────────────────────
    // Break levels are short counter-move lows = support zones ideal for adding long.
    // Use static marks so framework keeps one order alive per slot without cancel/recreate.
    if mkt_mode == 2 && has_long && long_entry_ok && !long_on_cd && !breakout_short
        && state.mv_cas_dir == 1 && state.mv_break_n > 0
    {
        let remaining = long_max * state.cfg.cap - long_n;
        let mut breaks: Vec<f64> = state.mv_breaks[..state.mv_break_n]
            .iter()
            .filter(|&&p| p > 0.0 && p < price)
            .copied()
            .collect();
        breaks.sort_by(|a, b| b.partial_cmp(a).unwrap()); // descending: nearest first
        let mv_marks = ["mv-le1", "mv-le2"];
        for (i, &bp) in breaks.iter().take(2).enumerate() {
            let amt = (remaining * 0.20 * lbias * lwm * lscale * drf).min(remaining);
            if amt > 1.0 { place_orders.push(limit_order(Direction::Long, amt, bp, mv_marks[i])); }
        }
    }

    // ── Long TPs ─────────────────────────────────────────────────────────────
    if has_long && long_n > min_tp_notional {
        let long_budget = long_max * state.cfg.cap;
        if mode == -2 && long_n > long_budget + 10.0 {
            let trim = ((long_n - long_budget) * 0.35).min(long_n * 0.30);
            if trim > 1.0 { place_orders.push(tp_order_with_band(Direction::Long, trim, price - tick, "l-t1", "l-ub")); }
        } else if mode == 1 {
            let tp_price = state.mrc_ub;
            if tp_price > price && !state.filled.contains("l-ub") {
                let amt = long_n * 0.90;
                if amt > 1.0 { place_orders.push(tp_order_with_band(Direction::Long, amt, tp_price, "l-t1", "l-ub")); }
            }
        } else {
            let mut candidates: Vec<(f64, &str)> = long_tp_levels.iter()
                .filter(|(p, band)| *p > 0.0 && *p > price && !state.filled.contains(*band))
                .copied().collect();
            candidates.sort_by(|a, b| (a.0 - price).partial_cmp(&(b.0 - price)).unwrap_or(std::cmp::Ordering::Equal));
            let marks = ["l-t1", "l-t2"];
            let pcts  = [0.30, 0.20];
            for (i, &(bp, band)) in candidates.iter().take(state.cfg.nearest).enumerate() {
                let amt = long_n * pcts[i];
                if amt > 1.0 { place_orders.push(tp_order_with_band(Direction::Long, amt, bp, marks[i], band)); }
            }
        }
    }

    // ── Short entries ─────────────────────────────────────────────────────────
    if has_short && short_entry_ok && !short_on_cd && !breakout_long && imbalance_ok_short && short_n < short_max * state.cfg.cap {
        let remaining = short_max * state.cfg.cap - short_n;
        let mut candidates: Vec<(f64, &str)> = short_entry_levels.iter()
            .filter(|(p, band)| *p > 0.0 && *p > price && *p > state.mrc_ml && !state.filled.contains(*band))
            .copied().collect();
        candidates.sort_by(|a, b| (a.0 - price).partial_cmp(&(b.0 - price)).unwrap_or(std::cmp::Ordering::Equal));
        let marks = ["s-e1", "s-e2"];
        let weights = [0.35, 0.25];
        for (i, &(bp, band)) in candidates.iter().take(state.cfg.nearest).enumerate() {
            let amt = (remaining * weights[i] * sbias * swm * sscale * drf).min(remaining);
            if amt > 1.0 { place_orders.push(limit_order_with_band(Direction::Short, amt, bp, marks[i], band)); }
        }
        // s-ext: only when selling pressure confirmed; place above current price (not at-market)
        if candidates.is_empty() && price > state.mrc_ub && remaining > 1.0 && state.vol_bsg < 0.0 {
            let ext_price = price + (state.mrc_range * 0.10).max(4.0 * tick);
            let amt = (remaining * 0.15 * sbias * swm * sscale * drf).min(remaining);
            if amt > 1.0 { place_orders.push(limit_order(Direction::Short, amt, ext_price, "s-ext")); }
        }
    }

    // ── Cascade DCA entries: short (TrendShort mode only) ─────────────────────
    // Break levels are long counter-move highs = resistance zones ideal for adding short.
    if mkt_mode == -2 && has_short && short_entry_ok && !short_on_cd && !breakout_long
        && state.mv_cas_dir == -1 && state.mv_break_n > 0
    {
        let remaining = short_max * state.cfg.cap - short_n;
        let mut breaks: Vec<f64> = state.mv_breaks[..state.mv_break_n]
            .iter()
            .filter(|&&p| p > 0.0 && p > price)
            .copied()
            .collect();
        breaks.sort_by(|a, b| a.partial_cmp(b).unwrap()); // ascending: nearest first
        let mv_marks = ["mv-se1", "mv-se2"];
        for (i, &bp) in breaks.iter().take(2).enumerate() {
            let amt = (remaining * 0.20 * sbias * swm * sscale * drf).min(remaining);
            if amt > 1.0 { place_orders.push(limit_order(Direction::Short, amt, bp, mv_marks[i])); }
        }
    }

    // ── Short TPs ─────────────────────────────────────────────────────────────
    if has_short && short_n > min_tp_notional {
        let short_budget = short_max * state.cfg.cap;
        if mode == 2 && short_n > short_budget + 10.0 {
            let trim = ((short_n - short_budget) * 0.35).min(short_n * 0.30);
            if trim > 1.0 { place_orders.push(tp_order_with_band(Direction::Short, trim, price + tick, "s-t1", "s-db")); }
        } else if mode == 1 {
            let tp_price = state.mrc_db;
            if tp_price < price && !state.filled.contains("s-db") {
                let amt = short_n * 0.90;
                if amt > 1.0 { place_orders.push(tp_order_with_band(Direction::Short, amt, tp_price, "s-t1", "s-db")); }
            }
        } else {
            let mut candidates: Vec<(f64, &str)> = short_tp_levels.iter()
                .filter(|(p, band)| *p > 0.0 && *p < price && !state.filled.contains(*band))
                .copied().collect();
            candidates.sort_by(|a, b| (price - a.0).partial_cmp(&(price - b.0)).unwrap_or(std::cmp::Ordering::Equal));
            let marks = ["s-t1", "s-t2"];
            let pcts  = [0.30, 0.20];
            for (i, &(bp, band)) in candidates.iter().take(state.cfg.nearest).enumerate() {
                let amt = short_n * pcts[i];
                if amt > 1.0 { place_orders.push(tp_order_with_band(Direction::Short, amt, bp, marks[i], band)); }
            }
        }
    }

    // ── Trend-following DCA: add to position as price moves in cascade direction ─
    // Places a limit order 1 tick ahead of current price — fills on the very next tick move.
    // Only fires when the movement cascade CONFIRMS the direction we already hold.
    // Bypasses the drift gate deliberately: this is WITH the trend, not against it.
    // Static mark keeps exactly one live order per side; the framework updates price each tick.
    if has_short && !short_on_cd && !breakout_long && mkt_mode != 2
        && state.mv_cas_dir == -1 && short_n < short_max * state.cfg.cap
    {
        let remaining = short_max * state.cfg.cap - short_n;
        let amt = (remaining * 0.15 * sbias * swm * sscale * drf).min(remaining);
        if amt > 1.0 { place_orders.push(limit_order(Direction::Short, amt, price - tick, "dca-s")); }
    }
    if has_long && !long_on_cd && !breakout_short && mkt_mode != -2
        && state.mv_cas_dir == 1 && long_n < long_max * state.cfg.cap
    {
        let remaining = long_max * state.cfg.cap - long_n;
        let amt = (remaining * 0.15 * lbias * lwm * lscale * drf).min(remaining);
        if amt > 1.0 { place_orders.push(limit_order(Direction::Long, amt, price + tick, "dca-l")); }
    }

    // ── Spike-catcher: bearish spike → add short entry ────────────────────────
    // Place above price at grid distance so it only fills on a real upward spike, not immediately.
    if state.bearish_spike && has_short && state.tf5.mov < -20.0 && imbalance_ok_short && state.vol_bsg < 0.0 {
        let remaining = short_max * state.cfg.cap - short_n;
        let spike_price = price + (state.mrc_range * 0.10).max(4.0 * tick);
        let amt = (remaining * 0.15 * sbias * swm * sscale * drf).min(remaining);
        if amt > 1.0 { place_orders.push(limit_order(Direction::Short, amt, spike_price, "s-spike")); }
    }

    // ── Extended TPs for trend modes (2-3x MRC window beyond upper/lower band) ─
    let half_range = (state.mrc_ub - state.mrc_db) * 0.5;
    if mkt_mode == 2 && has_long && long_n > min_tp_notional && half_range > 0.0 {
        let ext1 = state.mrc_ub + half_range;
        let ext2 = state.mrc_ub + half_range * 2.0;
        if ext1 > price && !state.filled.contains("l-ext-t1") {
            let amt = long_n * 0.20;
            if amt > 1.0 { place_orders.push(tp_order_with_band(Direction::Long, amt, ext1, "l-ext-t1", "l-ext-t1")); }
        }
        if ext2 > price && !state.filled.contains("l-ext-t2") {
            let amt = long_n * 0.15;
            if amt > 1.0 { place_orders.push(tp_order_with_band(Direction::Long, amt, ext2, "l-ext-t2", "l-ext-t2")); }
        }
    }
    if mkt_mode == -2 && has_short && short_n > min_tp_notional && half_range > 0.0 {
        let ext1 = state.mrc_db - half_range;
        let ext2 = state.mrc_db - half_range * 2.0;
        if ext1 < price && !state.filled.contains("s-ext-t1") {
            let amt = short_n * 0.20;
            if amt > 1.0 { place_orders.push(tp_order_with_band(Direction::Short, amt, ext1, "s-ext-t1", "s-ext-t1")); }
        }
        if ext2 < price && !state.filled.contains("s-ext-t2") {
            let amt = short_n * 0.15;
            if amt > 1.0 { place_orders.push(tp_order_with_band(Direction::Short, amt, ext2, "s-ext-t2", "s-ext-t2")); }
        }
    }

    // ── Spike-exit: recovery → partial close short ────────────────────────────
    // Fires once per position (s-ts in filled prevents re-fire after fill).
    // Use mrc_ub as static price so the order doesn't move every tick
    // (moving price = cancel/recreate storm generating no-note BUY orders).
    if has_short && short_n > min_tp_notional && !state.filled.contains("s-ts") {
        let mut close_pct = 0.0_f64;
        if state.bullish_spike && state.tf5.regime == -2 { close_pct = close_pct.max(0.20); }
        if state.tf1.cross > state.tf1.cross_prev && state.tf1.cross_prev < 0 {
            close_pct = close_pct.max(match state.tf1.cross { 0=>0.30, 1..=4=>0.50, _=>0.15 });
        }
        if state.smc_dir == 1 && state.smc_dir_prev == -1 { close_pct = close_pct.max(0.70); }
        let amt = short_n * close_pct;
        let ts_price = if state.mrc_ub > price { state.mrc_ub } else { price + (state.mrc_range * 0.10).max(4.0 * tick) };
        if amt > 1.0 { place_orders.push(tp_order_with_band(Direction::Short, amt, ts_price, "s-ts", "s-ts")); }
    }

    place_orders
}

// ── FinishPosition / NewPosition ───────────────────────────────────────────

fn handle_finish(input: &ModuleInput, state: &mut State, direction: Direction) -> ModuleOutput {
    match direction {
        Direction::Long => {
            state.long_close_tick = state.ticks;
            state.filled.retain(|k| !k.starts_with("l-") && !k.starts_with("tc-cl"));
            state.long_entry_idx = -1;
            state.long_tp_idx = -1;
            state.mode_close_l = 0;
        }
        Direction::Short => {
            state.short_close_tick = state.ticks;
            state.filled.retain(|k| !k.starts_with("s-") && !k.starts_with("tc-cs"));
            state.short_entry_idx = -1;
            state.short_tp_idx = -1;
            state.mode_close_s = 0;
        }
        _ => {}
    }
    ModuleOutput {
        debug: format!("finish {:?} t={} p={:.2}", direction, state.ticks, input.price),
        ..Default::default()
    }
}

// ── Movement cascade ─────────────────────────────────────────────────────────
//
// Ports movementCascade.ts into an incremental per-candle algorithm.
// Direction is determined by vol_bsg sign (>= 0 = Long, < 0 = Short).
// Counter-moves whose high-low size is < 40% of the rolling avg cascade size
// are absorbed: their extreme price is recorded as a break level (support/
// resistance DCA zone) and the parent cascade block continues.

pub fn update_movement(state: &mut State, vol_bsg: f64, high: f64, low: f64) {
    if high <= 0.0 || low <= 0.0 { return; }
    let dir: i8 = if vol_bsg >= 0.0 { 1 } else { -1 };

    if state.mv_dir == 0 {
        state.mv_dir = dir; state.mv_high = high; state.mv_low = low; state.mv_candles = 1;
        state.mv_cas_dir = dir; state.mv_cas_high = high; state.mv_cas_low = low;
        state.mv_cas_candles = 1;
        return;
    }

    if dir == state.mv_dir {
        if high > state.mv_high { state.mv_high = high; }
        if low  < state.mv_low  { state.mv_low  = low;  }
        state.mv_candles += 1;
        if dir == state.mv_cas_dir {
            if high > state.mv_cas_high { state.mv_cas_high = high; }
            if low  < state.mv_cas_low  { state.mv_cas_low  = low;  }
            state.mv_cas_candles += 1;
        }
        return;
    }

    // Raw block just completed in direction mv_dir — evaluate for cascade absorption.
    let completed_size = state.mv_high - state.mv_low;
    let threshold      = if state.mv_avg_size > 0.0 { state.mv_avg_size * 0.40 } else { f64::MAX };
    let is_counter     = state.mv_dir != state.mv_cas_dir;
    let absorb         = is_counter && completed_size < threshold;

    if absorb {
        // Small counter-move: record break level and extend cascade range.
        // mv_dir == -1 (short counter in long cascade) → break price = counter LOW (support)
        // mv_dir == +1 (long counter in short cascade) → break price = counter HIGH (resistance)
        let break_price = if state.mv_dir == -1 { state.mv_low } else { state.mv_high };
        if state.mv_break_n >= 5 {
            state.mv_breaks.rotate_left(1);
            state.mv_breaks[4] = break_price;
        } else {
            state.mv_breaks[state.mv_break_n] = break_price;
            state.mv_break_n += 1;
        }
        if state.mv_high > state.mv_cas_high { state.mv_cas_high = state.mv_high; }
        if state.mv_low  < state.mv_cas_low  { state.mv_cas_low  = state.mv_low;  }
        // First candle of the resuming cascade direction also extends the cascade.
        if dir == state.mv_cas_dir {
            if high > state.mv_cas_high { state.mv_cas_high = high; }
            if low  < state.mv_cas_low  { state.mv_cas_low  = low;  }
            state.mv_cas_candles += 1;
        }
    } else {
        // Real reversal: commit current cascade to history, start a new one.
        let cas_size = state.mv_cas_high - state.mv_cas_low;
        if cas_size > 0.0 {
            state.mv_sizes[state.mv_sizes_pos] = cas_size;
            state.mv_sizes_pos = (state.mv_sizes_pos + 1) % 10;
            if state.mv_sizes_len < 10 { state.mv_sizes_len += 1; }
            state.mv_avg_size = state.mv_sizes[..state.mv_sizes_len].iter().sum::<f64>()
                / state.mv_sizes_len as f64;
        }
        state.mv_cas_dir = dir;
        state.mv_cas_high = high.max(state.mv_high);
        state.mv_cas_low  = low.min(state.mv_low);
        state.mv_cas_candles = 1;
        state.mv_break_n = 0;
        state.mv_breaks = [0.0; 5];
    }

    state.mv_dir = dir; state.mv_high = high; state.mv_low = low; state.mv_candles = 1;
}

/// Rebuild movement cascade from the 10-candle Init history (oldest-first pass).
pub fn init_movement(ind: &Indicators, state: &mut State) {
    for offset in (0..10usize).rev() {
        let bsg  = read_float(ind, TF, offset, "volume_50", "BuySellGain").unwrap_or(0.0);
        let high = read_float(ind, TF, offset, CANDLE_IND, "High").unwrap_or(0.0);
        let low  = read_float(ind, TF, offset, CANDLE_IND, "Low").unwrap_or(0.0);
        update_movement(state, bsg, high, low);
    }
}

// ── Market mode observer ─────────────────────────────────────────────────────
//
// Classifies current state into Sideways (1), TrendLong (2), TrendShort (-2).
// Requires cascade block > 1.2× avg AND at least 2 of 3 TFs agreeing.
// Mode commits after 2 consecutive confirming candles (hysteresis).

fn classify_mode(state: &State) -> i8 {
    if state.mv_sizes_len < 3 || state.mv_avg_size < 0.001 { return 1; }
    let cas_size   = state.mv_cas_high - state.mv_cas_low;
    let size_ratio = cas_size / state.mv_avg_size;
    if size_ratio < 1.2 { return 1; }

    let dir = state.mv_cas_dir;
    let agrees = match dir {
        1 => {
            (state.tf1.cross >= 1) as u8
            + (state.tf5.regime == 2) as u8
            + (state.tf15.regime >= 1) as u8
        }
        -1 => {
            (state.tf1.cross <= -1) as u8
            + (state.tf5.regime == -2) as u8
            + (state.tf15.regime <= -1) as u8
        }
        _ => 0,
    };
    if agrees >= 2 {
        // Sanity check: tf1.cross is real-time price zone (-4..+4).
        // A bullish cascade can lag while price has already dropped to the lower range.
        let cross_contradicts = (dir == 1 && state.tf1.cross <= -2)
            || (dir == -1 && state.tf1.cross >= 2);
        // Priority 2.1: above-avg volume candle on opposing side confirms the trend is wrong.
        // Tighter than cross_contradicts: cross <= -1 (below ML) + real volume = genuine reversal.
        let volume_contradicts = (dir == 1 && state.tf1.cross <= -1 && state.vol_gain > 0.0)
            || (dir == -1 && state.tf1.cross >= 1 && state.vol_gain > 0.0);
        // Priority 2.3: extreme market activity with strong BSG opposing the proposed trend direction.
        let ntps_contradicts = state.ntps > 400
            && ((dir == 1 && state.vol_bsg < -1.5) || (dir == -1 && state.vol_bsg > 1.5));
        if cross_contradicts || volume_contradicts || ntps_contradicts { 1 } else { dir * 2 }
    } else { 1 }
}

pub fn advance_market_mode(state: &mut State) {
    let candidate = classify_mode(state);
    if candidate == state.mkt_mode {
        state.mkt_mode_candles += 1;
        state.mkt_cand = candidate;
        state.mkt_cand_candles = 0;
    } else if candidate == state.mkt_cand {
        state.mkt_cand_candles += 1;
        if state.mkt_cand_candles >= 3 {
            state.mkt_mode = candidate;
            state.mkt_mode_candles = 0;
            state.mkt_cand_candles = 0;
            // Reset transition-close progress on every mode change.
            state.mode_close_l = 0;
            state.mode_close_s = 0;
            state.filled.retain(|k| !k.starts_with("tc-"));
        }
    } else {
        state.mkt_cand = candidate;
        state.mkt_cand_candles = 1;
    }
}

// ── Risk ratchet ─────────────────────────────────────────────────────────────
//
// Combines two signals:
//   peak_factor: how far auto_max_amount is below its all-time high (profit drawn down)
//   floor_factor: how far auto_max_amount is below the starting max_amount (net loss)
// Both scale entry amounts; the geometric mean softens the combined effect.

pub fn update_risk_ratchet(state: &mut State, max_amount: f64, auto_max_amount: f64) {
    if max_amount <= 0.0 { return; }
    let current = if auto_max_amount > 0.0 { auto_max_amount } else { max_amount };
    if current > state.risk_peak_auto { state.risk_peak_auto = current; }

    let peak_factor = if state.risk_peak_auto > 0.0 {
        (current / state.risk_peak_auto).clamp(0.10, 1.0)
    } else { 1.0 };

    // Penalise only when auto_max_amount has fallen below the starting budget.
    let floor_factor = if auto_max_amount > 0.0 && auto_max_amount < max_amount {
        (auto_max_amount / max_amount).max(0.10)
    } else { 1.0 };

    state.risk_drawdown = (peak_factor * floor_factor).sqrt().clamp(0.10, 1.0);
}

// ── Helpers ─────────────────────────────────────────────────────────────────

fn win_mult(pos: Option<&lte_strategy_bridge::abi::ModulePositionSummary>) -> f64 {
    let ratio = pos
        .map(|p| {
            if p.notional > 1.0 {
                p.pnl / p.notional
            } else {
                0.0
            }
        })
        .unwrap_or(0.0);
    if ratio > 0.0 {
        1.0 + (ratio * 5.0).min(0.5)
    } else {
        1.0
    }
}

fn mid(a: f64, b: f64) -> f64 {
    (a + b) / 2.0
}

// ── MRC / SMC helpers ───────────────────────────────────────────────────────

fn apply_mrc_bands(state: &mut State, bands: &[f64; 9]) {
    // Read ML 5 candles ago from history — works on both Init and Indicators
    // (Indicators events only carry 1 candle, so we can't use input.indicators for lookback)
    let key_ml = IndicatorFieldKey {
        timeframe: TimeframeSec::Tf1m,
        indicator: IndicatorKey::Mrc200,
        field: IndicatorField::MeanLine,
    };
    let ml_prev = match state.history.get_prev(key_ml, 5) {
        Some(ModuleIndicatorValue::Float(f)) => *f,
        _ => 0.0,
    };

    state.has_mrc = true;
    state.mrc_db = bands[0];
    state.mrc_do = bands[1];
    state.mrc_ds = bands[2];
    state.mrc_di = bands[3];
    state.mrc_ml = bands[4];
    state.mrc_ui = bands[5];
    state.mrc_us = bands[6];
    state.mrc_uo = bands[7];
    state.mrc_ub = bands[8];
    state.mrc_range = bands[8] - bands[0];
    state.mrc_ml_prev = ml_prev;
    if ml_prev > 0.0 && state.mrc_range > 0.0 {
        state.angle = (bands[4] - ml_prev) / state.mrc_range;
    }
}

fn read_smc_dir(ind: &Indicators) -> i8 {
    match read_direction(ind, TF, 0, SMC_IND, "Direction") {
        Some(Direction::Long) => 1,
        Some(Direction::Short) => -1,
        _ => 0,
    }
}

// ── Per-TF movement tracking ─────────────────────────────────────────────────

fn init_tf_from_ind(ind: &Indicators, state: &mut State, tf_sec: i64) {
    for offset in (0..10usize).rev() {
        if read_float(ind, tf_sec, offset, MRC, "MeanLine").is_none() {
            continue;
        }
        let cross = read_float(ind, tf_sec, offset, MRC, "CurrentCross")
            .map(|f| f.round() as i8)
            .unwrap_or(0);
        let candle_dir = match read_direction(ind, tf_sec, offset, CANDLE_IND, "Direction") {
            Some(Direction::Long) => 1i8,
            Some(Direction::Short) => -1i8,
            _ => 0i8,
        };
        {
            let tf_state = match tf_sec {
                TF => &mut state.tf1,
                TF_5M => &mut state.tf5,
                TF_15M => &mut state.tf15,
                TF_30M => &mut state.tf30,
                _ => return,
            };
            advance_tf(tf_state, cross, candle_dir, 0.0);
        }
        // Populate level stats, interest line, and zone streaks from history
        // so the first SugInfo can immediately evaluate stair/V-bounce conditions
        if tf_sec == TF {
            update_interest_line(state);
            update_level_stats(state);
            update_zone_streak(state);
        }
    }
}

fn advance_tf_from_ind(ind: &Indicators, state: &mut State, tf_sec: i64) {
    let cross = match read_float(ind, tf_sec, 0, MRC, "CurrentCross") {
        Some(f) => f.round() as i8,
        None => return,
    };
    let candle_dir = match read_direction(ind, tf_sec, 0, CANDLE_IND, "Direction") {
        Some(Direction::Long) => 1i8,
        Some(Direction::Short) => -1i8,
        _ => 0i8,
    };
    {
        let tf_state = match tf_sec {
            TF => &mut state.tf1,
            TF_5M => &mut state.tf5,
            TF_15M => &mut state.tf15,
            TF_30M => &mut state.tf30,
            _ => return,
        };
        advance_tf(tf_state, cross, candle_dir, 0.0);
    }
    // After 1m candle: update interest line, per-level statistics, zone streaks
    if tf_sec == TF {
        update_interest_line(state);
        update_level_stats(state);
        update_zone_streak(state);
    }
}

fn advance_tf(tf: &mut TfMovState, cross: i8, candle_dir: i8, ext: f64) {
    let prev_cross = tf.cross;
    tf.cross_prev2 = tf.cross_prev;
    tf.cross_prev = prev_cross;
    tf.candles += 1;
    tf.cross = cross;

    tf.history[tf.hist_pos] = cross;
    tf.hist_pos = (tf.hist_pos + 1) % 20;
    if tf.hist_len < 20 {
        tf.hist_len += 1;
    }

    // Floor/ceiling from full ring buffer
    let (mut mn, mut mx) = (cross, cross);
    for i in 0..tf.hist_len {
        let idx = (tf.hist_pos + 20 - 1 - i) % 20;
        let v = tf.history[idx];
        if v < mn { mn = v; }
        if v > mx { mx = v; }
    }
    let old_floor = tf.floor;
    let old_ceiling = tf.ceiling;
    tf.floor = mn;
    tf.ceiling = mx;
    tf.floor_age = if mn != old_floor || tf.candles == 1 { 0 } else { tf.floor_age + 1 };
    tf.ceiling_age = if mx != old_ceiling || tf.candles == 1 { 0 } else { tf.ceiling_age + 1 };

    // Angle sign: track consecutive cross movement direction
    let delta = cross.saturating_sub(prev_cross).signum();
    if delta != 0 {
        if delta == tf.angle_sign {
            tf.angle_sign_candles += 1;
        } else {
            tf.angle_sign = delta;
            tf.angle_sign_candles = 1;
        }
    }

    // Slow mov update: ±step per candle based on cross level, body/shadow, extension
    let dir_sign = cross.signum() as f64;
    let abs_cross = cross.abs() as f64;
    let body_factor: f64 = if candle_dir != 0
        && ((candle_dir > 0 && cross > 0) || (candle_dir < 0 && cross < 0))
    {
        1.5 // body agrees with cross = confirmed directional cross
    } else if candle_dir != 0 {
        0.7 // body opposes = shadow cross = weaker
    } else {
        1.0
    };
    let ext_bonus = ext.abs().min(3.0);
    let step = dir_sign * (1.0 + abs_cross * 0.8 + ext_bonus) * body_factor;
    let momentum = if (tf.mov > 20.0 && step > 0.0) || (tf.mov < -20.0 && step < 0.0) {
        1.3
    } else if (tf.mov > 0.0 && step < 0.0) || (tf.mov < 0.0 && step > 0.0) {
        0.5
    } else {
        1.0
    };
    tf.mov = (tf.mov + step * momentum).clamp(-100.0, 100.0);
    if cross == 0 {
        tf.mov *= 0.85;
    }

    tf.regime = classify_regime(tf);
    tf.conf = compute_conf(tf);
}

fn update_volume_spike(ind: &Indicators, state: &mut State) {
    let gain     = read_float(ind, TF, 0, "volume_50", "Gain").unwrap_or(0.0);
    let gain_min = read_float(ind, TF, 0, "volume_50", "GainMin").unwrap_or(-1.0);
    let gain_max = read_float(ind, TF, 0, "volume_50", "GainMax").unwrap_or(1.0);
    let bsg      = read_float(ind, TF, 0, "volume_50", "BuySellGain").unwrap_or(0.0);
    let bsg_min  = read_float(ind, TF, 0, "volume_50", "BuySellGainMin").unwrap_or(-1.0);
    let bsg_max  = read_float(ind, TF, 0, "volume_50", "BuySellGainMax").unwrap_or(1.0);

    state.vol_gain_prev = state.vol_gain;
    state.vol_gain     = gain;
    state.vol_gain_max = gain_max;
    state.vol_gain_min = gain_min;
    state.vol_bsg      = bsg;
    state.vol_bsg_max  = bsg_max;
    state.vol_bsg_min  = bsg_min;

    // Spike detection: normalize within 50-candle range to find outlier candles
    let gain_range = (gain_max - gain_min).max(f64::EPSILON);
    let bsg_range  = (bsg_max  - bsg_min ).max(f64::EPSILON);
    let gain_pct   = (gain - gain_min) / gain_range; // 1.0 = biggest candle in 50c
    let bsg_pct    = (bsg  - bsg_min ) / bsg_range;  // 0.0 = max selling, 1.0 = max buying

    // Large candle (top half of 50c range) + strong directional pressure
    state.bearish_spike = gain_pct > 0.50 && bsg_pct < 0.30;
    state.bullish_spike = gain_pct > 0.50 && bsg_pct > 0.70;

    // Priority 1.1: track exhaustion candles (BSG > 2.0 = climax buy; BSG < -2.0 = climax sell)
    if state.bullish_spike && bsg > 2.0 {
        state.bsg_exhaustion_long_candle = state.tf1.candles;
    }
    if state.bearish_spike && bsg < -2.0 {
        state.bsg_exhaustion_short_candle = state.tf1.candles;
    }
}

// ── Interest line ────────────────────────────────────────────────────────────
//
// Tracks which MRC cross zone is the current "key level" — the level price
// has been repeatedly testing without breaking. The more tests without a break,
// the stronger the signal in that direction.
//
// Logic:
//   - delta > 0 (cross moved up) and aligns with interest_dir → advance frontier
//   - delta > 0 but opposes interest_dir (e.g. brief bounce) → count as test
//   - penetration >1 zone opposite → interest flipped, new direction
fn update_interest_line(state: &mut State) {
    let cross = state.tf1.cross;
    let prev  = state.tf1.cross_prev;

    if cross == prev {
        state.interest_age = state.interest_age.saturating_add(1);
        return;
    }

    let delta = (cross - prev).signum() as i8;

    if state.interest_dir == 0 {
        state.interest_cross = cross;
        state.interest_dir   = delta;
        state.interest_age   = 0;
        return;
    }

    if delta == state.interest_dir {
        // Continuing in the same direction: advance the frontier
        if (delta > 0 && cross > state.interest_cross)
            || (delta < 0 && cross < state.interest_cross)
        {
            state.interest_cross = cross;
            state.interest_tests = 0; // moved past old level
        }
        state.interest_age += 1;
    } else {
        // Moving opposite — measure how deep the counter-move is
        let depth: i8 = match state.interest_dir {
            1  => (state.interest_cross - cross).max(0),
            _  => (cross - state.interest_cross).max(0),
        };

        if depth <= 1 {
            // Shallow bounce: treat as a test of the interest level
            state.interest_tests = state.interest_tests.saturating_add(1);
            state.interest_age  += 1;
        } else {
            // Penetrated 2+ zones: interest broken, flip direction
            state.interest_cross = cross;
            state.interest_dir   = delta;
            state.interest_age   = 0;
            state.interest_tests = 0;
        }
    }
}

// ── Per-level statistics ──────────────────────────────────────────────────────
//
// Maps 1m cross transitions onto the 9 LevelStats slots:
//   Boundary index: -4↔-3=0(DB)  -3↔-2=1(DO)  -2↔-1=2(DS)  -1↔0=3(DI)
//                    0↔+1=5(UI)   +1↔+2=6(US)  +2↔+3=7(UO)  +3↔+4=8(UB)
//   Slot 4 (ML) lives inside zone 0 — updated via price in update_level_min_dists.
//
// A V-pattern: cross[t-2]=A, cross[t-1]=B (crossed A/B boundary), cross[t]=A again.
// Indicates price tested the level but was rejected — counted as a "test" not a crossing.
fn update_level_stats(state: &mut State) {
    let cross = state.tf1.cross;
    let prev  = state.tf1.cross_prev;
    let prev2 = state.tf1.cross_prev2;

    if cross == prev { return; }

    let low_zone = prev.min(cross);
    let bidx: usize = match low_zone {
        -4 => 0, -3 => 1, -2 => 2, -1 => 3,
        0  => 5, 1  => 6, 2  => 7, 3  => 8,
        _  => return,
    };

    let ls = &mut state.level_stats[bidx];
    let delta = (cross - prev).signum() as i8;

    let candle_ts = state.tf1.candles;

    if prev2 == cross {
        // V-pattern: crossed the boundary then reversed back within 1 candle.
        // Direction of V is the direction of the brief excursion (prev relative to cross):
        //   prev > cross → dropped below then bounced back up → bullish V (support held)
        //   prev < cross → rose above then fell back down → bearish V (resistance held)
        if prev > cross {
            ls.v_bull += 1;
        } else {
            ls.v_bear += 1;
        }
        ls.current_tests += 1;
        ls.last_v_candle  = candle_ts;
        ls.min_dist       = 0.0;
    } else {
        // Sustained crossing
        ls.crossings        += 1;
        ls.last_cross_dir    = delta;
        ls.last_cross_candle = candle_ts;
        ls.current_tests     = 0;
        ls.min_dist          = 0.0;
    }
}

// Maintain zone_streak: consecutive 1m candles price has spent in each cross zone.
// Called on every 1m candle close (after advance_tf updates cross/cross_prev).
fn update_zone_streak(state: &mut State) {
    let cross = state.tf1.cross;
    let prev  = state.tf1.cross_prev;

    let cidx = (cross + 4) as usize;
    if cidx >= 9 { return; }

    if cross == prev {
        state.zone_streak[cidx] += 1;
    } else {
        // Reset old zone, start fresh in new zone
        let pidx = (prev + 4) as usize;
        if pidx < 9 { state.zone_streak[pidx] = 0; }
        state.zone_streak[cidx] = 1;
    }
}

// Update min approach distance for each MRC level on every SugInfo tick.
// Tracks how close price gets to each band without crossing it.
fn update_level_min_dists(state: &mut State, price: f64) {
    if !state.has_mrc { return; }
    let levels = [
        state.mrc_db, state.mrc_do, state.mrc_ds, state.mrc_di,
        state.mrc_ml,
        state.mrc_ui, state.mrc_us, state.mrc_uo, state.mrc_ub,
    ];
    let cz = state.tf1.cross;
    for (idx, &lvl) in levels.iter().enumerate() {
        if lvl <= 0.0 { continue; }
        let adjacent = match idx {
            0 => cz == -4 || cz == -3,
            1 => cz == -3 || cz == -2,
            2 => cz == -2 || cz == -1,
            3 => cz == -1 || cz == 0,
            4 => cz == 0,
            5 => cz == 0  || cz == 1,
            6 => cz == 1  || cz == 2,
            7 => cz == 2  || cz == 3,
            8 => cz == 3  || cz == 4,
            _ => false,
        };
        if adjacent {
            let dist = (price - lvl).abs();
            let ls = &mut state.level_stats[idx];
            if ls.min_dist <= 0.0 || dist < ls.min_dist {
                ls.min_dist = dist;
            }
        }
    }
}

// ── Entry scale from interest + regime + asymmetry ───────────────────────────
//
// Returns (long_scale, short_scale) multipliers applied to all entry amounts.
//
// Interest line boost: when price has tested a level N times without breaking,
// entries in the confirmed direction scale up proportionally.
//
// Strong-side asymmetry: one side breaks extreme bands while the other is stuck
// at a near-ML level. Example: price above UpBig for 5+ candles (zone_streak[8])
// while short side can't reach DownBig (DownBig never crossed, price drifting near
// DownInner) → market has a strong directional bias, entries follow it.
//
// Sideways dead zone: WIN regime near MeanLine (pzone 0.38-0.62) — cut entries
// opposing the SMC direction to avoid fading a ranging market.
fn compute_entry_scale(state: &State, pzone: f64) -> (f64, f64) {
    let mut lscale = 1.0_f64;
    let mut sscale = 1.0_f64;

    // ── Interest line boost ───────────────────────────────────────────────
    let itests = state.interest_tests;
    if itests >= 3 {
        let boost = ((itests - 2) as f64 * 0.20).min(0.80);
        match state.interest_dir {
            -1 => {
                sscale *= 1.0 + boost;
                lscale *= (1.0 - boost * 0.5).max(0.30);
            }
            1 => {
                lscale *= 1.0 + boost;
                sscale *= (1.0 - boost * 0.5).max(0.30);
            }
            _ => {}
        }
    }

    // ── Strong-side asymmetry ─────────────────────────────────────────────
    // zone_streak[8] = candles above UpBig; zone_streak[0] = candles below DownBig
    // last_cross_candle age = how recently that extreme boundary was broken
    let now = state.tf1.candles;
    let ub_streak  = state.zone_streak[8]; // consecutive candles at cross=+4 (above UpBig)
    let db_streak  = state.zone_streak[0]; // consecutive candles at cross=-4 (below DownBig)
    let ub_cross_age = if state.level_stats[8].last_cross_candle > 0 {
        now.saturating_sub(state.level_stats[8].last_cross_candle)
    } else {
        u64::MAX
    };
    let db_cross_age = if state.level_stats[0].last_cross_candle > 0 {
        now.saturating_sub(state.level_stats[0].last_cross_candle)
    } else {
        u64::MAX
    };

    // Strong long: price has been above UpBig (or recently broke through it upward)
    //              while DownBig was never / very long ago crossed downward
    let strong_long = (ub_streak >= 5 || (ub_cross_age < 30 && state.level_stats[8].last_cross_dir == 1))
        && db_cross_age > 60;
    // Strong short: symmetric — price below DownBig while UpBig is stale
    let strong_short = (db_streak >= 5 || (db_cross_age < 30 && state.level_stats[0].last_cross_dir == -1))
        && ub_cross_age > 60;

    if strong_long {
        lscale *= 1.40;
        sscale *= 0.50;
    } else if strong_short {
        sscale *= 1.40;
        lscale *= 0.50;
    }

    // ── Sideways dead zone ────────────────────────────────────────────────
    if state.tf1.regime == 1 && pzone > 0.38 && pzone < 0.62 {
        match state.smc_dir {
            1  => sscale *= 0.35,
            -1 => lscale *= 0.35,
            _  => {
                lscale *= 0.60;
                sscale *= 0.60;
            }
        }
    }

    (lscale.max(0.10), sscale.max(0.10))
}

fn classify_regime(tf: &TfMovState) -> i8 {
    if tf.hist_len < 10 {
        return 0; // UNK — warming up
    }
    // floor=ceiling=non-zero: price locked at one cross level for hist_len candles → early trend
    if tf.floor == tf.ceiling && tf.floor != 0 {
        return if tf.floor > 0 { 2 } else { -2 };
    }
    // floor >= -1: never dips below DownInner → floor is high
    // ceiling <= 1: never pushes above UpInner → ceiling is low
    match (tf.floor >= -1, tf.ceiling <= 1) {
        (true, false) => 2,   // UP: high floor + pushes up
        (false, true) => -2,  // DOWN: low ceiling + sinks down
        _ => 1,               // WIN: ranging (both sides active, or tight around ML)
    }
}

fn compute_conf(tf: &TfMovState) -> u8 {
    if tf.hist_len < 5 {
        return 0;
    }
    let hist_score = (tf.hist_len.min(20) as f64 / 20.0) * 40.0;
    let mov_score = tf.mov.abs().min(100.0) / 100.0 * 40.0;
    let stability = if tf.floor_age > 5 && tf.ceiling_age > 5 { 20.0 }
        else if tf.floor_age > 3 || tf.ceiling_age > 3 { 10.0 }
        else { 0.0 };
    ((hist_score + mov_score + stability) as u8).min(100)
}

fn tf_debug(tf: &TfMovState) -> String {
    let r = match tf.regime { 2 => "TUP", -2 => "TDN", 1 => "SWY", _ => "UNK" };
    format!(
        "{}(m={:.0} c={} f={}/{} C={}/{} n={})",
        r, tf.mov, tf.cross, tf.floor, tf.floor_age, tf.ceiling, tf.ceiling_age, tf.candles
    )
}

fn compute_allocation(smc_dir: Option<Direction>, pzone: f64, angle: f64, mov5: f64, mode: i8) -> (f64, f64) {
    // Trend direction gets the majority; counter-trend is hedge-only
    let mut long_r = match mode {
        2  => 0.70_f64,  // Trend UP: primary long
        -2 => 0.30_f64,  // Trend DOWN: primary short
        _  => 0.50_f64,  // Sideways/UNK: balanced
    };

    match smc_dir {
        Some(Direction::Long) => long_r += 0.05,
        Some(Direction::Short) => long_r -= 0.05,
        _ => {}
    }

    if pzone < 0.35 { long_r += 0.05; }
    if pzone > 0.65 { long_r -= 0.05; }

    if angle > 0.01 { long_r -= 0.05; }
    if angle < -0.01 { long_r += 0.05; }

    // 5m mov directional tilt: up to ±10% shift
    let mov5_bias = (mov5 / 100.0) * 0.10;
    long_r -= mov5_bias;

    long_r = long_r.clamp(0.15, 0.85);
    (long_r, 1.0 - long_r)
}

fn compute_bias(angle: f64, pzone: f64, trandm: f64, mov5: f64) -> (f64, f64) {
    let mut lbias = 1.0_f64;
    let mut sbias = 1.0_f64;

    if angle > 0.005 && pzone > 0.6 {
        sbias = 1.3;
        lbias = 0.8;
    }
    if angle < -0.005 && pzone < 0.4 {
        lbias = 1.3;
        sbias = 0.8;
    }

    if trandm > 70.0 {
        sbias *= 1.2;
        lbias *= 0.8;
    }
    if trandm < 30.0 {
        lbias *= 1.2;
        sbias *= 0.8;
    }

    // 5m mov order-size tilt
    if mov5 < -40.0 {
        lbias *= 0.7;
        sbias *= 1.3;
    } else if mov5 > 40.0 {
        sbias *= 0.7;
        lbias *= 1.3;
    }

    (lbias, sbias)
}

fn market_open(direction: Direction, amount: f64, note: &str) -> ModuleOpenPosition {
    ModuleOpenPosition {
        direction,
        amount: Some(amount),
        qty: None,
        enter_price: None,
        order_type: "Market".to_string(),
        take_profit: None,
        stop_loss: None,
        note: note.to_string(),
    }
}

fn close(direction: Direction, reason: &str) -> ModuleClosePosition {
    ModuleClosePosition {
        direction,
        reason: reason.to_string(),
    }
}

fn limit_order(direction: Direction, amount: f64, price: f64, mark: &str) -> ModulePlaceOrder {
    ModulePlaceOrder {
        direction,
        amount: Some(amount),
        qty: None,
        enter_price: price,
        take_profit: None,
        stop_loss: None,
        mark: mark.to_string(),
        order_side: match direction {
            Direction::Long => ModuleOrderSide::Buy,
            Direction::Short => ModuleOrderSide::Sell,
            _ => ModuleOrderSide::Buy,
        },
        reduce_only: false,
    }
}

fn limit_order_with_band(
    direction: Direction,
    amount: f64,
    price: f64,
    mark: &str,
    band: &str,
) -> ModulePlaceOrder {
    ModulePlaceOrder {
        direction,
        amount: Some(amount),
        qty: None,
        enter_price: price,
        take_profit: None,
        stop_loss: None,
        mark: format!("{}:{}", mark, band),
        order_side: match direction {
            Direction::Long => ModuleOrderSide::Buy,
            Direction::Short => ModuleOrderSide::Sell,
            _ => ModuleOrderSide::Buy,
        },
        reduce_only: false,
    }
}

fn tp_order_with_band(
    direction: Direction,
    amount: f64,
    price: f64,
    mark: &str,
    band: &str,
) -> ModulePlaceOrder {
    ModulePlaceOrder {
        direction,
        amount: Some(amount),
        qty: None,
        enter_price: price,
        take_profit: None,
        stop_loss: None,
        mark: format!("{}:{}", mark, band),
        order_side: match direction {
            Direction::Long => ModuleOrderSide::Sell,
            Direction::Short => ModuleOrderSide::Buy,
            _ => ModuleOrderSide::Buy,
        },
        reduce_only: true,
    }
}

// ── Indicator access ────────────────────────────────────────────────────────

type Indicators = BTreeMap<i64, Vec<HashMap<String, HashMap<String, ModuleIndicatorValue>>>>;

fn read_float(ind: &Indicators, tf: i64, idx: usize, name: &str, field: &str) -> Option<f64> {
    ind.get(&tf)?
        .get(idx)?
        .get(name)?
        .get(field)
        .and_then(|v| match v {
            ModuleIndicatorValue::Float(f) => Some(*f),
            _ => None,
        })
}

fn read_direction(
    ind: &Indicators,
    tf: i64,
    idx: usize,
    name: &str,
    field: &str,
) -> Option<Direction> {
    ind.get(&tf)?
        .get(idx)?
        .get(name)?
        .get(field)
        .and_then(|v| match v {
            ModuleIndicatorValue::Direction(d) => Some(*d),
            // ModuleIndicatorValue is #[serde(untagged)] with String before Direction,
            // so "LONG"/"SHORT" strings get deserialized as String, not Direction.
            ModuleIndicatorValue::String(s) => match s.as_str() {
                "LONG"  => Some(Direction::Long),
                "SHORT" => Some(Direction::Short),
                "BOTH"  => Some(Direction::Both),
                _ => None,
            },
            _ => None,
        })
}

fn read_mrc(ind: &Indicators) -> Option<[f64; 9]> {
    Some([
        read_float(ind, TF, 0, MRC, "DownBig")?,
        read_float(ind, TF, 0, MRC, "DownOuter")?,
        read_float(ind, TF, 0, MRC, "DownSmall")?,
        read_float(ind, TF, 0, MRC, "DownInner")?,
        read_float(ind, TF, 0, MRC, "MeanLine")?,
        read_float(ind, TF, 0, MRC, "UpInner")?,
        read_float(ind, TF, 0, MRC, "UpSmall")?,
        read_float(ind, TF, 0, MRC, "UpOuter")?,
        read_float(ind, TF, 0, MRC, "UpBig")?,
    ])
}

fn read_analysis(input: &ModuleInput) -> (i64, f64) {
    match &input.sug_info {
        Some(s) => (s.indicator.ntps, s.indicator.trandm),
        None => (0, 50.0),
    }
}
