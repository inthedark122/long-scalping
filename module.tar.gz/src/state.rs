use std::collections::{HashMap, HashSet};
use lte_strategy_bridge::indicator_access::IndicatorHistory;

// ── Per-timeframe movement state ───────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct TfMovState {
    pub candles: u64,
    pub cross: i8,              // current zone (-4..+4), 0 = MeanLine zone
    pub history: [i8; 20],      // ring buffer of cross levels
    pub hist_pos: usize,        // next write index
    pub hist_len: usize,        // valid entries (0..=20)
    pub floor: i8,              // min(history) — deepest pullback seen
    pub ceiling: i8,            // max(history) — highest push seen
    pub floor_age: u64,         // candles since floor last changed
    pub ceiling_age: u64,
    pub angle_sign: i8,         // +1 / -1 / 0
    pub angle_sign_candles: u64,
    pub mov: f64,               // slow movement score -100..+100
    pub regime: i8,             // 0=UNK  1=Sideways  2=TrendUP  -2=TrendDOWN
    pub conf: u8,               // confidence 0-100
    pub cross_prev: i8,         // cross level from the previous candle
    pub cross_prev2: i8,        // cross level from two candles ago (V-pattern detection)
}

impl Default for TfMovState {
    fn default() -> Self {
        Self {
            candles: 0,
            cross: 0,
            history: [0i8; 20],
            hist_pos: 0,
            hist_len: 0,
            floor: 0,
            ceiling: 0,
            floor_age: 0,
            ceiling_age: 0,
            angle_sign: 0,
            angle_sign_candles: 0,
            mov: 0.0,
            regime: 0,
            conf: 0,
            cross_prev: 0,
            cross_prev2: 0,
        }
    }
}

// ── Per-MRC-level statistics ─────────────────────────────────────────────────
//
// 9 entries indexed 0-8 corresponding to:
//   0=DownBig  1=DownOuter  2=DownSmall  3=DownInner  4=MeanLine
//   5=UpInner  6=UpSmall    7=UpOuter    8=UpBig
//
// Boundaries 0-3 and 5-8 are cross-zone transitions.
// Entry 4 (MeanLine) lives inside zone 0 and is tracked by price proximity.
#[derive(Debug, Clone, Copy, Default)]
pub struct LevelStats {
    pub crossings: u32,          // times price crossed through this boundary
    pub v_bull: u32,             // bullish V: dropped below level, bounced back up (support held)
    pub v_bear: u32,             // bearish V: rose above level, fell back down (resistance held)
    pub current_tests: u32,      // consecutive V-bounces without a real crossing (streak)
    pub min_dist: f64,           // closest price approach without crossing (0=unset)
    pub last_cross_dir: i8,      // direction of last actual crossing (+1=up, -1=down)
    pub last_cross_candle: u64,  // tf1.candles when last crossing occurred (0=never)
    pub last_v_candle: u64,      // tf1.candles when last V-pattern occurred (0=never)
}

// ── Config ──────────────────────────────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct Config {
    pub breakout_guard: bool,
    pub imbalance_guard: bool,
    pub margin_sl: bool,
    pub imbalance_ratio: f64,
    pub breakout_ntps: i64,
    pub sl_margin_pct: f64,
    pub seed: f64,
    pub cap: f64,
    pub cooldown_ticks: u64,
    pub nearest: usize,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            breakout_guard: true,
            imbalance_guard: false,
            margin_sl: true,
            imbalance_ratio: 3.0,
            breakout_ntps: 300,
            sl_margin_pct: 0.7,
            seed: 0.05,
            cap: 0.90,
            cooldown_ticks: 5,
            nearest: 2,
        }
    }
}

impl Config {
    pub fn apply(&mut self, values: &HashMap<String, serde_json::Value>) {
        for (k, v) in values {
            let n = v.as_f64().or_else(|| v.as_str().and_then(|s| s.parse().ok()));
            let Some(n) = n else { continue };
            match k.as_str() {
                "breakout_guard" => self.breakout_guard = n != 0.0,
                "imbalance_guard" => self.imbalance_guard = n != 0.0,
                "margin_sl" => self.margin_sl = n != 0.0,
                "imbalance_ratio" => self.imbalance_ratio = n,
                "breakout_ntps" => self.breakout_ntps = n as i64,
                "sl_margin_pct" => self.sl_margin_pct = n,
                "seed" => self.seed = n,
                "cap" => self.cap = n,
                "cooldown_ticks" => self.cooldown_ticks = n as u64,
                "nearest" => self.nearest = n as usize,
                _ => {}
            }
        }
    }
}

// ── State ───────────────────────────────────────────────────────────────────

pub struct State {
    pub ticks: u64,
    pub ntps: i64,
    pub trandm: f64,
    pub mrc_range: f64,
    pub long_close_tick: u64,
    pub short_close_tick: u64,
    // Cached from Indicators (not serialized)
    pub last_ind_tick: u64,
    pub has_mrc: bool,
    pub mrc_db: f64,
    pub mrc_do: f64,
    pub mrc_ds: f64,
    pub mrc_di: f64,
    pub mrc_ml: f64,
    pub mrc_ui: f64,
    pub mrc_us: f64,
    pub mrc_uo: f64,
    pub mrc_ub: f64,
    pub mrc_ml_prev: f64,
    pub angle: f64,
    pub smc_dir: i8,
    pub smc_dir_prev: i8,
    // Interest line: the last MRC cross level broken — high-priority entry zone
    pub interest_cross: i8,  // which cross level was just broken through
    pub interest_dir: i8,    // +1=bullish break (add longs), -1=bearish (add shorts), 0=none
    pub interest_tests: u32, // consecutive bounces off interest level without breaking it
    pub interest_age: u64,   // 1m candles since interest was last updated
    // Volume data (updated on each 1m candle close — raw indicator values)
    pub vol_gain: f64,       // Gain ratio: >0 = above baseline, <0 = below (e.g. +1.5 = 150% more)
    pub vol_gain_prev: f64,  // previous candle's gain (track expanding vs shrinking)
    pub vol_gain_max: f64,   // 50-candle max gain (sets "how big is big")
    pub vol_gain_min: f64,   // 50-candle min gain
    pub vol_bsg: f64,        // BuySellGain: >0 = buying pressure, <0 = selling pressure
    pub vol_bsg_max: f64,    // 50-candle max bsg (strongest buying seen)
    pub vol_bsg_min: f64,    // 50-candle min bsg (strongest selling, negative)
    pub bearish_spike: bool, // large candle + strong selling → add short
    pub bullish_spike: bool, // large candle + strong buying → partial close short
    // BSG exhaustion candle timestamps for counter-trend entry gate (Priority 1.1)
    pub bsg_exhaustion_long_candle: u64,   // tf1.candles when last buy-exhaustion (BSG>2.0) fired
    pub bsg_exhaustion_short_candle: u64,  // tf1.candles when last sell-exhaustion (BSG<-2.0) fired
    // Indicator history (init+update, not serialized)
    pub history: IndicatorHistory,
    // Per-TF movement analysis (debug only, not serialized)
    pub tf1: TfMovState,
    pub tf5: TfMovState,
    pub tf15: TfMovState,
    pub tf30: TfMovState,
    // Per-MRC-level statistics (debug/analysis, 9 entries: DB DO DS DI ML UI US UO UB)
    pub level_stats: [LevelStats; 9],
    // Consecutive 1m candles price has spent at each cross zone (index = cross+4, 0=zone-4 .. 8=zone+4)
    // High streak at zone+4 = price above UpBig for N candles; high at zone-1 = stuck at DownInner, etc.
    pub zone_streak: [u64; 9],
    // Filled level names — skip these when placing new grid orders
    pub filled: HashSet<String>,
    // Last filled band index per category (-1 = none)
    pub long_entry_idx: i8,
    pub long_tp_idx: i8,
    pub short_entry_idx: i8,
    pub short_tp_idx: i8,
    pub cfg: Config,

    // ── Movement cascade tracker ──────────────────────────────────────────────
    // Raw block: consecutive candles with the same vol_bsg sign.
    pub mv_dir: i8,          // +1 Long, -1 Short, 0=uninit
    pub mv_high: f64,        // raw block price range
    pub mv_low: f64,
    pub mv_candles: u32,
    // Cascade block: absorbs raw counter-moves < 40% of rolling avg size.
    pub mv_cas_dir: i8,
    pub mv_cas_high: f64,
    pub mv_cas_low: f64,
    pub mv_cas_candles: u32,
    // Break levels: extreme of each absorbed counter-move.
    //   Long cascade → short counter lows  (support / DCA-buy zones)
    //   Short cascade → long counter highs (resistance / DCA-sell zones)
    pub mv_breaks: [f64; 5],
    pub mv_break_n: usize,
    // Ring buffer of completed cascade block sizes → rolling avg threshold.
    pub mv_sizes: [f64; 10],
    pub mv_sizes_pos: usize,
    pub mv_sizes_len: usize,
    pub mv_avg_size: f64,

    // ── Market mode ───────────────────────────────────────────────────────────
    // 0=UNK  1=Sideways  2=TrendLong  -2=TrendShort
    pub mkt_mode: i8,
    pub mkt_mode_candles: u32,   // consecutive candles in current confirmed mode
    pub mkt_cand: i8,            // pending mode candidate
    pub mkt_cand_candles: u32,   // candles confirming candidate (commit at >= 2)
    pub mode_close_l: u8,        // long-side transition close stage (0=none,1=25%,2=50%,3=done)
    pub mode_close_s: u8,        // short-side transition close stage

    // ── Risk ratchet ──────────────────────────────────────────────────────────
    pub risk_init_max: f64,      // max_amount captured on Init (starting budget)
    pub risk_peak_auto: f64,     // highest auto_max_amount seen since Init
    pub risk_drawdown: f64,      // entry scale factor: 1.0=normal, <1.0=drawdown
}

impl Default for State {
    fn default() -> Self {
        Self {
            ticks: 0,
            ntps: 0,
            trandm: 0.0,
            mrc_range: 0.0,
            long_close_tick: 0,
            short_close_tick: 0,
            last_ind_tick: 0,
            has_mrc: false,
            mrc_db: 0.0,
            mrc_do: 0.0,
            mrc_ds: 0.0,
            mrc_di: 0.0,
            mrc_ml: 0.0,
            mrc_ui: 0.0,
            mrc_us: 0.0,
            mrc_uo: 0.0,
            mrc_ub: 0.0,
            mrc_ml_prev: 0.0,
            angle: 0.0,
            smc_dir: 0,
            smc_dir_prev: 0,
            interest_cross: 0,
            interest_dir: 0,
            interest_tests: 0,
            interest_age: 0,
            vol_gain: 0.0,
            vol_gain_prev: 0.0,
            vol_gain_max: 1.0,
            vol_gain_min: -1.0,
            vol_bsg: 0.0,
            vol_bsg_max: 1.0,
            vol_bsg_min: -1.0,
            bearish_spike: false,
            bullish_spike: false,
            bsg_exhaustion_long_candle: 0,
            bsg_exhaustion_short_candle: 0,
            history: IndicatorHistory::default(),
            tf1: TfMovState::default(),
            tf5: TfMovState::default(),
            tf15: TfMovState::default(),
            tf30: TfMovState::default(),
            level_stats: [LevelStats::default(); 9],
            zone_streak: [0u64; 9],
            filled: HashSet::new(),
            long_entry_idx: -1,
            long_tp_idx: -1,
            short_entry_idx: -1,
            short_tp_idx: -1,
            cfg: Config::default(),
            // Movement cascade
            mv_dir: 0, mv_high: 0.0, mv_low: 0.0, mv_candles: 0,
            mv_cas_dir: 0, mv_cas_high: 0.0, mv_cas_low: 0.0, mv_cas_candles: 0,
            mv_breaks: [0.0; 5], mv_break_n: 0,
            mv_sizes: [0.0; 10], mv_sizes_pos: 0, mv_sizes_len: 0, mv_avg_size: 0.0,
            // Market mode
            mkt_mode: 0, mkt_mode_candles: 0, mkt_cand: 0, mkt_cand_candles: 0,
            mode_close_l: 0, mode_close_s: 0,
            // Risk ratchet
            risk_init_max: 0.0, risk_peak_auto: 0.0, risk_drawdown: 1.0,
        }
    }
}

pub fn save(s: &State) -> Option<serde_json::Value> {
    serde_json::to_value(StateSerde {
        ticks: s.ticks,
        long_close_tick: s.long_close_tick,
        short_close_tick: s.short_close_tick,
        long_entry_idx: s.long_entry_idx,
        long_tp_idx: s.long_tp_idx,
        short_entry_idx: s.short_entry_idx,
        short_tp_idx: s.short_tp_idx,
        interest_cross: s.interest_cross,
        interest_dir: s.interest_dir,
        interest_tests: s.interest_tests,
        mkt_mode: s.mkt_mode,
        mkt_mode_candles: s.mkt_mode_candles,
    })
    .ok()
}

#[derive(serde::Serialize)]
struct StateSerde {
    ticks: u64,
    long_close_tick: u64,
    short_close_tick: u64,
    long_entry_idx: i8,
    long_tp_idx: i8,
    short_entry_idx: i8,
    short_tp_idx: i8,
    interest_cross: i8,
    interest_dir: i8,
    interest_tests: u32,
    mkt_mode: i8,
    mkt_mode_candles: u32,
}
